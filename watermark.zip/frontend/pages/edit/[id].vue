<template>
    <main>
        <Header />
        <WatermarkEditor />
    </main>
</template>

<script setup>
import WatermarkEditor from '~/components/WatermarkEditor.vue'
</script>