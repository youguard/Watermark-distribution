const dotenv = require('dotenv').config()

const config = {
    DBURI : process.env.DBURI
}
module.exports = config